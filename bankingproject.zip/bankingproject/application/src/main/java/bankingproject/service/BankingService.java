package bankingproject.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class BankingService {

    @Scheduled(fixedRate = 5000)
    public void test()
    {
        System.out.println("running main");
    }
}
